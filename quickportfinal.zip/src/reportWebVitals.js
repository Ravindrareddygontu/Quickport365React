import React from 'react'

function reportWebVitals() {
  return (
    <div>
      
    </div>
  )
}

export default reportWebVitals
