import React from "react";
import  '../components/Address.css'
function Address(){
return(
    <div>
        <div className="col-md-6 col-lg- col-6">
            <div className="PickUp Address">
            <h4 className="h4class">
            PickUp Address
             </h4>
             
            </div>
        </div>
        <div className="col-md-6 col-lg-6 col-6">
            
            </div>
    </div>
)
}
export default Address